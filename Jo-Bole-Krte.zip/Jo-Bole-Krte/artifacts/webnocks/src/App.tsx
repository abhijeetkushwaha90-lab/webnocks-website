import { useState, useEffect, useRef } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

const queryClient = new QueryClient();

const ANSWERS: Record<string, string> = {
  "What services do you offer?": "We offer AI Automation, SEO, Web Development, Data Intelligence, Cloud & DevOps, Cybersecurity, Logo Design, and Lead Generation.",
  "How much does SEO cost?": "Our pricing varies based on your needs, but our Starter plan begins at ₹15,000/mo. Check our Pricing page for more details!",
  "How long for results?": "For SEO, typically 3-6 months. For Web Dev and AI Automation, we deliver initial phases within 2-4 weeks depending on complexity.",
  "Do you work internationally?": "Yes! We serve clients in 20+ countries worldwide. Distance is no barrier to world-class IT solutions."
};

const PROMPTS = [
  { cat: 'SEO', title: 'Topical Authority Content Plan', desc: 'Generate a comprehensive semantic SEO cluster strategy.', prompt: 'Act as an expert SEO strategist. Create a topical authority map and content cluster strategy for the niche: [INSERT NICHE]. Provide a pillar page concept and 10 supporting cluster articles. For each, include the target keyword, search intent, and a proposed H1.' },
  { cat: 'SEO', title: 'On-Page Audit Checklist', desc: 'Analyze content for on-page SEO factors.', prompt: 'Review the following content for on-page SEO best practices targeting the keyword [INSERT KEYWORD]. Provide specific recommendations for title tags, meta descriptions, H-tag structure, keyword density, and internal linking opportunities: [PASTE CONTENT]' },
  { cat: 'SEO', title: 'Local SEO Strategy', desc: 'Step-by-step local search dominance plan.', prompt: 'Create a local SEO strategy for a [BUSINESS TYPE] in [CITY]. Include GMB optimization tips, local citation sources, and a 3-month local content plan.' },
  { cat: 'Web Dev', title: 'React Component Architecture', desc: 'Structure a scalable React component system.', prompt: 'Act as a Senior React Engineer. Propose a scalable component architecture for a [TYPE OF APP]. Outline the folder structure, state management approach, and key reusable components needed.' },
  { cat: 'Web Dev', title: 'API Endpoint Design', desc: 'Design RESTful API endpoints for a feature.', prompt: 'Design the REST API endpoints for a [FEATURE] in a SaaS application. Include the HTTP methods, paths, request payloads, and response structures for standard CRUD operations.' },
  { cat: 'Web Dev', title: 'Performance Optimization', desc: 'Identify frontend performance bottlenecks.', prompt: 'What are the top 5 performance optimization techniques for a React single-page application that is experiencing slow load times and janky animations? Provide actionable code examples.' },
  { cat: 'Business', title: 'Go-to-Market Strategy', desc: 'Launch plan for a new digital product.', prompt: 'Act as a startup founder. Outline a 90-day Go-to-Market strategy for a new B2B SaaS tool targeting [TARGET AUDIENCE]. Include channels, messaging, and key metrics.' },
  { cat: 'Business', title: 'Competitive Analysis', desc: 'Framework for analyzing market competitors.', prompt: 'Provide a structured framework for analyzing the top 3 competitors in the [INDUSTRY] space. What specific metrics, features, and marketing strategies should I evaluate?' },
  { cat: 'Business', title: 'Pricing Model Design', desc: 'Structure pricing tiers for a service.', prompt: 'Suggest a 3-tier pricing model for a [SERVICE/PRODUCT]. Define the target user for each tier, the features included, and the psychological pricing strategy.' },
  { cat: 'Data', title: 'KPI Dashboard Layout', desc: 'Metrics to track for executive dashboards.', prompt: 'I am building a Power BI dashboard for the CEO of a [INDUSTRY] company. What are the 7 most critical KPIs that should be on the main screen, and how should they be visualized?' },
  { cat: 'Data', title: 'SQL Query Generator', desc: 'Complex SQL queries for data analysis.', prompt: 'Write an advanced SQL query to find the top 10% of customers by lifetime value who have not made a purchase in the last 90 days. Assume standard tables for Customers, Orders, and OrderItems.' },
  { cat: 'Content', title: 'LinkedIn Thought Leadership', desc: 'Generate engaging LinkedIn posts.', prompt: 'Act as a B2B thought leader. Write a controversial but professional LinkedIn post about the future of [INDUSTRY TREND]. Include a hook, 3 key points, and a call-to-action for comments.' }
];

const WA_NUMBER = "917068252052";

function App() {
  const [activePage, setActivePage] = useState("home");
  const [menuOpen, setMenuOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [messages, setMessages] = useState<{text: string, who: 'bot' | 'user'}[]>([
    { text: "Hi there! 👋 I'm the Webnocks AI assistant. How can I help you today?", who: 'bot' }
  ]);
  const [chatInput, setChatInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [activeTab, setActiveTab] = useState("calendly");
  const [activePromptCat, setActivePromptCat] = useState("All");
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Contact form state
  const [contactName, setContactName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [contactService, setContactService] = useState("SEO & Growth Marketing");
  const [contactBudget, setContactBudget] = useState("Under ₹15,000/mo");
  const [contactMsg, setContactMsg] = useState("");

  // Application modal state
  const [applyModal, setApplyModal] = useState<{open: boolean, role: string}>({open: false, role: ""});
  const [appName, setAppName] = useState("");
  const [appEmail, setAppEmail] = useState("");
  const [appPhone, setAppPhone] = useState("");
  const [appExp, setAppExp] = useState("0–1 years");
  const [appLinkedIn, setAppLinkedIn] = useState("");
  const [appPortfolio, setAppPortfolio] = useState("");
  const [appCover, setAppCover] = useState("");

  const { toast } = useToast();

  const showPage = (id: string) => {
    setActivePage(id);
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, chatOpen]);

  // Lock body scroll when modal is open
  useEffect(() => {
    document.body.style.overflow = applyModal.open ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [applyModal.open]);

  const sendChat = (text?: string) => {
    const messageText = text || chatInput.trim();
    if (!messageText) return;
    setMessages(prev => [...prev, { text: messageText, who: 'user' }]);
    if (!text) setChatInput("");
    setTimeout(() => {
      const ans = ANSWERS[messageText] || "Great question! Our team will get back to you — WhatsApp us at +91 7068252052 for instant reply.";
      setMessages(prev => [...prev, { text: ans, who: 'bot' }]);
    }, 600);
  };

  const copyPrompt = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const msg = encodeURIComponent(
      `🌐 *New Website Enquiry — Webnocks*\n\n` +
      `👤 *Name:* ${contactName}\n` +
      `📧 *Email:* ${contactEmail}\n` +
      `🛠️ *Service:* ${contactService}\n` +
      `💰 *Budget:* ${contactBudget}\n` +
      `📝 *Message:* ${contactMsg}`
    );
    window.open(`https://wa.me/${WA_NUMBER}?text=${msg}`, '_blank');
    toast({ title: "Redirecting to WhatsApp", description: "Your details are pre-filled. Just hit send!" });
    setContactName(""); setContactEmail(""); setContactMsg("");
  };

  const openApply = (role: string) => {
    setApplyModal({open: true, role});
    setAppName(""); setAppEmail(""); setAppPhone(""); setAppExp("0–1 years");
    setAppLinkedIn(""); setAppPortfolio(""); setAppCover("");
  };

  const handleApplicationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const msg = encodeURIComponent(
      `📋 *Job Application — Webnocks*\n\n` +
      `🎯 *Role:* ${applyModal.role}\n` +
      `👤 *Name:* ${appName}\n` +
      `📧 *Email:* ${appEmail}\n` +
      `📱 *Phone:* ${appPhone}\n` +
      `⏳ *Experience:* ${appExp}\n` +
      `🔗 *LinkedIn:* ${appLinkedIn || 'Not provided'}\n` +
      `💼 *Portfolio/GitHub:* ${appPortfolio || 'Not provided'}\n` +
      `📝 *Why Webnocks:* ${appCover}`
    );
    window.open(`https://wa.me/${WA_NUMBER}?text=${msg}`, '_blank');
    setApplyModal({open: false, role: ""});
    toast({ title: "Application Sent!", description: "We'll review your profile and get back to you soon." });
  };

  const filteredPrompts = activePromptCat === "All"
    ? PROMPTS
    : PROMPTS.filter(p => p.cat === activePromptCat);

  return (
    <QueryClientProvider client={queryClient}>
      <div className="app-container">
        {/* TICKER */}
        <div className="ticker">
          <div className="ticker-inner">
            <span>✦ AI Automation</span><span>✦ SEO Services</span><span>✦ Web Development</span>
            <span>✦ Data Analytics</span><span>✦ Cloud Solutions</span><span>✦ 20+ Countries</span>
            <span>✦ Build. Scale. Grow.</span><span>✦ AI Automation</span><span>✦ SEO Services</span>
            <span>✦ Web Development</span><span>✦ Data Analytics</span><span>✦ Cloud Solutions</span>
          </div>
          <div className="ticker-inner" aria-hidden="true">
            <span>✦ AI Automation</span><span>✦ SEO Services</span><span>✦ Web Development</span>
            <span>✦ Data Analytics</span><span>✦ Cloud Solutions</span><span>✦ 20+ Countries</span>
            <span>✦ Build. Scale. Grow.</span><span>✦ AI Automation</span><span>✦ SEO Services</span>
            <span>✦ Web Development</span><span>✦ Data Analytics</span><span>✦ Cloud Solutions</span>
          </div>
        </div>

        {/* NAVBAR */}
        <nav>
          <div className="nav-inner">
            <a className="nav-logo" onClick={() => showPage('home')}>Webnocks</a>
            <div className="nav-links hidden md:flex" id="navLinks">
              <a onClick={() => showPage('home')} className={activePage === 'home' ? 'active' : ''}>Home</a>
              <a onClick={() => showPage('services')} className={activePage === 'services' ? 'active' : ''}>Services</a>
              <a onClick={() => showPage('portfolio')} className={activePage === 'portfolio' ? 'active' : ''}>Portfolio</a>
              <a onClick={() => showPage('aiprompts')} className={activePage === 'aiprompts' ? 'active' : ''}>AI Prompts</a>
              <a onClick={() => showPage('pricing')} className={activePage === 'pricing' ? 'active' : ''}>Pricing</a>
              <a onClick={() => showPage('vision')} className={activePage === 'vision' ? 'active' : ''}>Vision</a>
              <a onClick={() => showPage('about')} className={activePage === 'about' ? 'active' : ''}>About</a>
              <a onClick={() => showPage('careers')} className={activePage === 'careers' ? 'active' : ''}>Careers</a>
              <a onClick={() => showPage('contact')} className={activePage === 'contact' ? 'active' : ''}>Contact</a>
            </div>
            <a className="btn-cta hidden md:inline-block" onClick={() => showPage('bookcall')}>Free Consultation</a>
            <button className="hamburger md:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu">☰</button>
          </div>
          <div className="mobile-menu" style={{ display: menuOpen ? 'flex' : 'none' }}>
            <a onClick={() => showPage('home')}>Home</a>
            <a onClick={() => showPage('services')}>Services</a>
            <a onClick={() => showPage('portfolio')}>Portfolio</a>
            <a onClick={() => showPage('aiprompts')}>AI Prompts</a>
            <a onClick={() => showPage('pricing')}>Pricing</a>
            <a onClick={() => showPage('vision')}>Vision</a>
            <a onClick={() => showPage('about')}>About</a>
            <a onClick={() => showPage('careers')}>Careers</a>
            <a onClick={() => showPage('contact')}>Contact</a>
            <a className="btn-cta" onClick={() => showPage('bookcall')}>Free Consultation</a>
          </div>
        </nav>

        <main>
          <AnimatePresence mode="wait">
            {/* PAGE: HOME */}
            {activePage === 'home' && (
              <motion.div 
                key="home"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="page active"
              >
                <section className="hero">
                  <div className="hero-bg"><div className="blob blob1"></div><div className="blob blob2"></div><div className="blob blob3"></div></div>
                  <div className="container hero-content">
                    <div className="badge">Global Digital Growth Agency</div>
                    <h1 className="hero-title serif">We don't just build websites,<br/><span className="grad-text">we grow your business online.</span></h1>
                    <p className="hero-sub">SEO, Websites & AI-powered solutions to bring you real customers.</p>
                    <div className="hero-btns">
                      <a className="btn-primary-lg" onClick={() => showPage('bookcall')}>Get Free Consultation →</a>
                      <a className="btn-outline" onClick={() => showPage('services')}>View Our Services</a>
                    </div>
                    <div className="stats-grid">
                      <div className="stat-card"><div className="stat-icon" style={{color:'#3b82f6'}}>👥</div><div className="stat-value" style={{color:'#3b82f6'}}>500+</div><div className="stat-label">Global Clients</div></div>
                      <div className="stat-card"><div className="stat-icon" style={{color:'#f59e0b'}}>🌍</div><div className="stat-value" style={{color:'#f59e0b'}}>20+</div><div className="stat-label">Countries Served</div></div>
                      <div className="stat-card"><div className="stat-icon" style={{color:'#60a5fa'}}>📊</div><div className="stat-value" style={{color:'#60a5fa'}}>200+</div><div className="stat-label">Projects Delivered</div></div>
                      <div className="stat-card"><div className="stat-icon" style={{color:'#22c55e'}}>✓</div><div className="stat-value" style={{color:'#22c55e'}}>98%</div><div className="stat-label">Satisfaction Rate</div></div>
                    </div>
                  </div>
                </section>

                {/* HOW WE GROW YOUR BUSINESS */}
                <section style={{background:'var(--card)'}}>
                  <div className="container">
                    <div className="section-title">
                      <span style={{display:'inline-block',fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.1em',color:'var(--secondary)',marginBottom:'8px'}}>Our Process</span>
                      <h2 className="serif">How We <span className="grad-text">Grow Your Business</span></h2>
                      <p>A clear, proven path from where you are to where you want to be — more traffic, more leads, more revenue.</p>
                    </div>
                    <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'0',position:'relative'}}>
                      {[
                        {step:'01',icon:'🌐',title:'Build Your Website',desc:'We build a fast, professional, mobile-first website that makes a powerful first impression and keeps visitors engaged.',color:'#3b82f6'},
                        {step:'02',icon:'🔍',title:'Rank on Google',desc:'Our SEO team gets you to the top of search results for keywords your customers are already searching.',color:'#f59e0b'},
                        {step:'03',icon:'🎯',title:'Generate Leads',desc:'Qualified enquiries start flowing in — real people who need what you sell, landing right in your inbox.',color:'#60a5fa'},
                        {step:'04',icon:'📈',title:'Increase Sales',desc:'We help you convert those leads into paying clients with optimized funnels, follow-ups, and conversion strategies.',color:'#22c55e'},
                      ].map((item,i)=>(
                        <div key={i} style={{padding:'36px 28px',borderTop:`3px solid ${item.color}`,background:'var(--bg)',marginRight: i<3?'1px':'0',transition:'all .3s',cursor:'default'}}
                          onMouseEnter={e=>(e.currentTarget.style.background='rgba(59,130,246,0.04)')}
                          onMouseLeave={e=>(e.currentTarget.style.background='var(--bg)')}>
                          <div style={{fontFamily:'Playfair Display,serif',fontSize:'48px',fontWeight:800,color:`${item.color}22`,marginBottom:'12px',lineHeight:1}}>{item.step}</div>
                          <div style={{fontSize:'32px',marginBottom:'16px'}}>{item.icon}</div>
                          <h3 style={{fontSize:'18px',fontWeight:700,marginBottom:'10px',color:'var(--text)'}}>{item.title}</h3>
                          <p style={{fontSize:'13px',color:'var(--muted)',lineHeight:1.65}}>{item.desc}</p>
                        </div>
                      ))}
                    </div>
                    <div style={{textAlign:'center',marginTop:'40px'}}>
                      <a className="btn-primary-lg" onClick={()=>showPage('bookcall')} style={{margin:'0 auto'}}>Start Growing Today →</a>
                    </div>
                  </div>
                </section>

                {/* LEAD SYSTEM PREVIEW */}
                <section>
                  <div className="container">
                    <div style={{background:'linear-gradient(135deg,rgba(59,130,246,0.07),rgba(5,5,8,0) 60%,rgba(245,158,11,0.05))',border:'1px solid rgba(59,130,246,0.2)',borderRadius:'32px',padding:'64px 48px'}}>
                      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'64px',alignItems:'center'}}>
                        <div>
                          <span style={{display:'inline-block',fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.1em',color:'var(--secondary)',marginBottom:'12px'}}>Exclusive Tool</span>
                          <h2 className="serif" style={{fontSize:'clamp(26px,4vw,42px)',marginBottom:'16px',lineHeight:1.2}}>Find Business Leads For <span className="grad-text">Your Industry</span></h2>
                          <p style={{color:'var(--muted)',fontSize:'16px',lineHeight:1.7,marginBottom:'28px'}}>We don't just do digital marketing — we bring you real, verified business leads. Tell us your industry and target country and we'll find your next customers.</p>
                          <div style={{display:'flex',flexDirection:'column',gap:'12px',marginBottom:'28px'}}>
                            {['B2B & B2C lead databases','Country & niche-specific targeting','Verified contact info (email, phone, LinkedIn)','Done-for-you outreach campaigns'].map((f,i)=>(
                              <div key={i} style={{display:'flex',alignItems:'center',gap:'10px',fontSize:'14px'}}>
                                <span style={{color:'var(--secondary)',fontWeight:700}}>✓</span>
                                <span style={{color:'var(--text)'}}>{f}</span>
                              </div>
                            ))}
                          </div>
                          <a className="btn-primary-lg" onClick={()=>showPage('contact')} style={{display:'inline-flex'}}>Get Leads For My Business →</a>
                        </div>
                        <div style={{background:'rgba(0,0,0,0.4)',border:'1px solid rgba(59,130,246,0.2)',borderRadius:'20px',padding:'32px'}}>
                          <div style={{marginBottom:'20px',fontSize:'15px',fontWeight:600,color:'var(--text)'}}>Try our Lead Finder</div>
                          <div style={{marginBottom:'12px'}}>
                            <label style={{display:'block',fontSize:'12px',fontWeight:600,color:'var(--muted)',marginBottom:'6px',textTransform:'uppercase',letterSpacing:'.06em'}}>Your Country / Target Market</label>
                            <select className="form-input" style={{fontSize:'14px'}}>
                              <option>🇺🇸 United States</option><option>🇬🇧 United Kingdom</option><option>🇦🇺 Australia</option>
                              <option>🇨🇦 Canada</option><option>🇦🇪 UAE</option><option>🇩🇪 Germany</option><option>🇸🇬 Singapore</option>
                            </select>
                          </div>
                          <div style={{marginBottom:'20px'}}>
                            <label style={{display:'block',fontSize:'12px',fontWeight:600,color:'var(--muted)',marginBottom:'6px',textTransform:'uppercase',letterSpacing:'.06em'}}>Your Niche / Industry</label>
                            <select className="form-input" style={{fontSize:'14px'}}>
                              <option>Real Estate Agents</option><option>Law Firms</option><option>Healthcare / Clinics</option>
                              <option>Restaurants & Food</option><option>E-Commerce Stores</option><option>SaaS Companies</option>
                              <option>Coaches & Consultants</option><option>Construction Companies</option>
                            </select>
                          </div>
                          <button className="btn-submit" onClick={()=>showPage('contact')} style={{borderRadius:'12px'}}>Find My Leads →</button>
                          <p style={{textAlign:'center',fontSize:'12px',color:'var(--muted)',marginTop:'12px'}}>This is a demo preview. Contact us for real leads.</p>
                          <div style={{marginTop:'16px',display:'flex',flexDirection:'column',gap:'8px'}}>
                            {[{name:'John M.',biz:'Real Estate - Florida',blur:true},{name:'Sarah K.',biz:'Law Firm - London',blur:true},{name:'Ahmad R.',biz:'Clinic - Dubai',blur:true}].map((l,i)=>(
                              <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 14px',background:'rgba(59,130,246,0.06)',border:'1px solid rgba(59,130,246,0.12)',borderRadius:'10px',filter:'blur(3px)',pointerEvents:'none'}}>
                                <span style={{fontSize:'13px',fontWeight:600}}>{l.name}</span>
                                <span style={{fontSize:'12px',color:'var(--muted)'}}>{l.biz}</span>
                              </div>
                            ))}
                          </div>
                          <div style={{textAlign:'center',marginTop:'8px',fontSize:'12px',color:'var(--secondary)',fontWeight:600}}>🔒 Unlock real leads — Contact us</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>

                {/* TRUST SECTION */}
                <section style={{background:'var(--card)'}}>
                  <div className="container">
                    <div className="section-title">
                      <span style={{display:'inline-block',fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.1em',color:'var(--secondary)',marginBottom:'8px'}}>Social Proof</span>
                      <h2 className="serif">Businesses That <span className="grad-text">Trust Webnocks</span></h2>
                      <p>Real results for real clients — from startups to scaling businesses worldwide.</p>
                    </div>
                    <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'20px',marginBottom:'60px',textAlign:'center'}}>
                      {[{val:'200+',label:'Projects Completed',color:'#3b82f6'},{val:'₹2Cr+',label:'Revenue Generated for Clients',color:'#f59e0b'},{val:'340%',label:'Avg Organic Traffic Growth',color:'#60a5fa'},{val:'98%',label:'Client Satisfaction Rate',color:'#22c55e'}].map((s,i)=>(
                        <div key={i} style={{padding:'28px 20px',background:'var(--bg)',border:'1px solid rgba(59,130,246,0.12)',borderRadius:'20px'}}>
                          <div style={{fontSize:'36px',fontWeight:800,color:s.color,marginBottom:'6px'}}>{s.val}</div>
                          <div style={{fontSize:'13px',color:'var(--muted)'}}>{s.label}</div>
                        </div>
                      ))}
                    </div>
                    <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'24px',marginBottom:'60px'}}>
                      {[
                        {name:'Rajesh Gupta',role:'E-Commerce Owner, UK',review:'Webnocks took our website from 0 to 8,000 monthly visitors in 5 months. Sales are up 3x. Worth every rupee.',stars:5,init:'RG',color:'#3b82f6'},
                        {name:'Sarah Mitchell',role:'Real Estate Agent, USA',review:'They built my website, set up my Google Ads, and now I get 15–20 inbound leads every month. Game changer.',stars:5,init:'SM',color:'#f59e0b'},
                        {name:'Ahmed Al-Rashid',role:'Clinic Director, UAE',review:'Professional team, fast delivery, and the SEO results speak for themselves. Page 1 for all my target keywords.',stars:5,init:'AR',color:'#60a5fa'},
                      ].map((t,i)=>(
                        <div key={i} style={{background:'var(--bg)',border:'1px solid rgba(59,130,246,0.15)',borderRadius:'20px',padding:'28px'}}>
                          <div style={{display:'flex',gap:'4px',marginBottom:'16px'}}>
                            {'★★★★★'.split('').map((s,j)=><span key={j} style={{color:'#f59e0b',fontSize:'16px'}}>{s}</span>)}
                          </div>
                          <p style={{fontSize:'14px',color:'var(--text)',lineHeight:1.7,marginBottom:'20px',fontStyle:'italic'}}>"{t.review}"</p>
                          <div style={{display:'flex',alignItems:'center',gap:'12px'}}>
                            <div style={{width:'40px',height:'40px',borderRadius:'50%',background:t.color,display:'flex',alignItems:'center',justifyContent:'center',fontSize:'14px',fontWeight:800,color:'#fff'}}>{t.init}</div>
                            <div>
                              <div style={{fontSize:'14px',fontWeight:700}}>{t.name}</div>
                              <div style={{fontSize:'12px',color:'var(--muted)'}}>{t.role}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:'24px',marginBottom:'40px'}}>
                      {[
                        {icon:'🏥',tag:'Case Study · Healthcare SEO',title:'Healthcare Clinic — 340% Traffic Growth',result:'Ranked #1 for 12 high-intent local keywords. Monthly leads went from 3 to 47.',color:'#3b82f6'},
                        {icon:'🛒',tag:'Case Study · E-Commerce',title:'Online Store — 3x Revenue in 6 Months',result:'Complete website rebuild + SEO + Google Ads. Revenue grew from ₹80K to ₹2.4L/month.',color:'#f59e0b'},
                      ].map((c,i)=>(
                        <div key={i} style={{background:'var(--bg)',border:`1px solid ${c.color}30`,borderRadius:'20px',padding:'28px',display:'flex',gap:'20px',alignItems:'flex-start'}}>
                          <div style={{fontSize:'40px',flexShrink:0}}>{c.icon}</div>
                          <div>
                            <span style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.08em',color:c.color}}>{c.tag}</span>
                            <h3 style={{fontSize:'16px',fontWeight:700,margin:'8px 0'}}>{c.title}</h3>
                            <p style={{fontSize:'13px',color:'var(--muted)',lineHeight:1.6,marginBottom:'12px'}}>{c.result}</p>
                            <a onClick={()=>showPage('contact')} style={{fontSize:'13px',fontWeight:700,color:c.color,cursor:'pointer'}}>Read Full Case Study →</a>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </section>

                <section>
                  <div className="container">
                    <div className="vision-teaser">
                      <span className="badge">Our Mission</span>
                      <h2 className="serif">Build. <span className="grad-text">Scale.</span> Grow.</h2>
                      <p>We are building a global digital ecosystem — combining AI, SEO, web development & lead generation into one powerhouse agency.</p>
                      <div className="journey-steps">
                        <div className="journey-step">Build Website</div>
                        <div className="journey-step">Rank on Google</div>
                        <div className="journey-step">Generate Leads</div>
                        <div className="journey-step">Increase Sales</div>
                      </div>
                      <a className="btn-primary-lg" onClick={() => showPage('vision')} style={{margin:'0 auto'}}>View Our Full Vision →</a>
                    </div>
                  </div>
                </section>

                <section>
                  <div className="container" style={{textAlign:'center'}}>
                    <h2 className="serif" style={{fontSize:'clamp(28px,4vw,48px)',marginBottom:'32px'}}>Serving <span style={{color:'var(--secondary)'}}>20+ Countries</span> Worldwide</h2>
                    <div className="countries">
                      <span className="country-tag">🇺🇸 USA</span><span className="country-tag">🇬🇧 UK</span><span className="country-tag">🇦🇺 Australia</span>
                      <span className="country-tag">🇨🇦 Canada</span><span className="country-tag">🇩🇪 Germany</span><span className="country-tag">🇮🇳 India</span>
                      <span className="country-tag">🇦🇪 UAE</span><span className="country-tag">🇸🇬 Singapore</span>
                      <span className="country-tag" style={{background:'rgba(59,130,246,0.1)',borderColor:'rgba(59,130,246,0.3)',color:'var(--primary)'}}>+ Many More</span>
                    </div>
                  </div>
                </section>

                <section style={{background:'var(--card)'}}>
                  <div className="container" style={{textAlign:'center'}}>
                    <h2 className="serif" style={{fontSize:'clamp(28px,4vw,48px)',marginBottom:'12px'}}>Ready to <span style={{color:'var(--primary)'}}>Elevate</span> Your Business?</h2>
                    <p style={{color:'var(--muted)',maxWidth:'560px',margin:'0 auto 40px',fontSize:'17px'}}>Join 500+ businesses that trust Webnocks to build, scale and grow their digital presence.</p>
                    <div style={{display:'flex',gap:'16px',justifyContent:'center',flexWrap:'wrap'}}>
                      <a className="btn-primary-lg" onClick={() => showPage('bookcall')}>Book Free Consultation</a>
                      <a className="btn-outline" onClick={() => showPage('contact')}>Contact Us</a>
                    </div>
                  </div>
                </section>
              </motion.div>
            )}

            {/* PAGE: SERVICES */}
            {activePage === 'services' && (
              <motion.div key="services" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="page active">
                <div className="container" style={{paddingBottom:'80px'}}>
                  <div className="section-title">
                    <h2 className="serif">Our <span style={{color:'var(--primary)'}}>Divisions</span></h2>
                    <p>Webnocks operates across 8 specialized IT divisions, providing end-to-end solutions for ambitious enterprises worldwide.</p>
                  </div>
                  <div className="services-grid">
                    <div className="card"><div className="card-icon" style={{background:'rgba(59,130,246,0.12)'}}>🧠</div><h3>Let AI Work For You 24/7</h3><p>We deploy AI agents that handle customer enquiries, follow up on leads, and automate repetitive tasks — so you earn more while working less.</p><div className="card-features"><span>Customer Support Agents</span><span>Lead Follow-up Automation</span><span>Workflow Automation</span><span>Chatbots That Convert</span></div><button className="card-btn" onClick={() => showPage('bookcall')}>Get AI Working For Me</button></div>
                    <div className="card"><div className="card-icon" style={{background:'rgba(34,197,94,0.12)'}}>🔍</div><h3>Get Found on Google, Get More Customers</h3><p>We rank your business at the top of Google search so high-intent buyers find you first — not your competitors.</p><div className="card-features"><span>Page 1 Google Rankings</span><span>High-Intent Keyword Targeting</span><span>Content That Ranks</span><span>Leads From Organic Search</span></div><button className="card-btn" onClick={() => showPage('bookcall')}>Rank My Business</button></div>
                    <div className="card"><div className="card-icon" style={{background:'rgba(59,130,246,0.12)'}}>💻</div><h3>Websites That Convert Visitors Into Customers</h3><p>We build fast, beautiful, mobile-first websites engineered to turn your traffic into real enquiries and sales — not just pretty pages.</p><div className="card-features"><span>Conversion-Optimized Design</span><span>Speed & Mobile-First</span><span>Lead Capture Forms</span><span>E-Commerce & SaaS</span></div><button className="card-btn" onClick={() => showPage('bookcall')}>Build My Website</button></div>
                    <div className="card"><div className="card-icon" style={{background:'rgba(234,179,8,0.12)'}}>📊</div><h3>Know Your Business Inside Out</h3><p>We turn your raw data into clear, visual dashboards so you always know what's working, what's not, and where to invest next.</p><div className="card-features"><span>Power BI Dashboards</span><span>Real-time KPI Tracking</span><span>Sales & Revenue Reports</span><span>Smart Decision-Making</span></div><button className="card-btn" onClick={() => showPage('bookcall')}>Get My Dashboard</button></div>
                    <div className="card"><div className="card-icon" style={{background:'rgba(96,165,250,0.12)'}}>☁️</div><h3>Never Lose a Customer to Downtime</h3><p>Rock-solid cloud infrastructure that keeps your website and systems online 24/7 — fast, secure, and always available.</p><div className="card-features"><span>AWS / Azure / GCP</span><span>99.9% Uptime Guarantee</span><span>Auto-Scaling</span><span>Disaster Recovery</span></div><button className="card-btn" onClick={() => showPage('bookcall')}>Secure My Infrastructure</button></div>
                    <div className="card"><div className="card-icon" style={{background:'rgba(239,68,68,0.12)'}}>🛡️</div><h3>Protect What You've Built</h3><p>We safeguard your website, data, and digital assets against hacks, breaches, and threats — so you can run your business without fear.</p><div className="card-features"><span>Security Audits</span><span>Penetration Testing</span><span>SSL & Firewall Setup</span><span>Compliance (SOC2/ISO)</span></div><button className="card-btn" onClick={() => showPage('bookcall')}>Secure My Business</button></div>
                    <div className="card"><div className="card-icon" style={{background:'rgba(245,158,11,0.12)'}}>🎨</div><h3>Make a Lasting First Impression</h3><p>A powerful logo and brand identity that builds instant trust, attracts premium clients, and sets you apart from the competition.</p><div className="card-features"><span>Logo Design</span><span>Brand Identity System</span><span>UI/UX Design</span><span>Marketing Creatives</span></div><button className="card-btn" onClick={() => showPage('bookcall')}>Brand My Business</button></div>
                    <div className="card"><div className="card-icon" style={{background:'rgba(249,115,22,0.12)'}}>🎯</div><h3>A Full Pipeline of Ready-to-Buy Clients</h3><p>We find, qualify, and deliver warm business leads to your inbox every month — so your sales team always has someone to talk to.</p><div className="card-features"><span>B2B & B2C Lead Databases</span><span>Verified Contact Info</span><span>LinkedIn & Email Outreach</span><span>Done-For-You Campaigns</span></div><button className="card-btn" onClick={() => showPage('bookcall')}>Find Me Leads</button></div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* PAGE: PORTFOLIO */}
            {activePage === 'portfolio' && (
              <motion.div key="portfolio" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="page active">
                <div className="container" style={{paddingBottom:'80px'}}>
                  <div className="section-title">
                    <h2 className="serif">Our <span style={{color:'var(--accent)'}}>Work</span></h2>
                    <p>From startups to global enterprises — a selection of projects we've engineered.</p>
                  </div>
                  <div className="portfolio-grid">
                    <div className="portfolio-card"><div className="portfolio-img">🛒</div><div className="portfolio-body"><h3 style={{fontSize:'17px',fontWeight:700,marginBottom:'8px'}}>E-Commerce Platform</h3><p style={{fontSize:'13px',color:'var(--muted)'}}>Full-stack e-commerce with AI-powered recommendations and real-time analytics.</p><div className="portfolio-tags"><span className="tag" style={{color:'var(--primary)',borderColor:'rgba(59,130,246,0.3)'}}>React</span><span className="tag" style={{color:'var(--accent)',borderColor:'rgba(96,165,250,0.3)'}}>Node.js</span><span className="tag" style={{color:'var(--green)',borderColor:'rgba(34,197,94,0.3)'}}>AI</span></div></div></div>
                    <div className="portfolio-card"><div className="portfolio-img">📈</div><div className="portfolio-body"><h3 style={{fontSize:'17px',fontWeight:700,marginBottom:'8px'}}>SaaS Analytics Dashboard</h3><p style={{fontSize:'13px',color:'var(--muted)'}}>Power BI-integrated dashboard serving C-suite executives across 3 continents.</p><div className="portfolio-tags"><span className="tag" style={{color:'var(--primary)',borderColor:'rgba(59,130,246,0.3)'}}>Power BI</span><span className="tag" style={{color:'var(--secondary)',borderColor:'rgba(245,158,11,0.3)'}}>Python</span></div></div></div>
                    <div className="portfolio-card"><div className="portfolio-img">🤖</div><div className="portfolio-body"><h3 style={{fontSize:'17px',fontWeight:700,marginBottom:'8px'}}>AI Customer Support Agent</h3><p style={{fontSize:'13px',color:'var(--muted)'}}>Deployed LLM-powered agent handling 10,000+ monthly support queries autonomously.</p><div className="portfolio-tags"><span className="tag" style={{color:'var(--accent)',borderColor:'rgba(96,165,250,0.3)'}}>GPT-4</span><span className="tag" style={{color:'var(--primary)',borderColor:'rgba(59,130,246,0.3)'}}>LangChain</span></div></div></div>
                    <div className="portfolio-card"><div className="portfolio-img">🏥</div><div className="portfolio-body"><h3 style={{fontSize:'17px',fontWeight:700,marginBottom:'8px'}}>Healthcare SEO Campaign</h3><p style={{fontSize:'13px',color:'var(--muted)'}}>Grew organic traffic 340% in 6 months for a UK-based healthcare provider.</p><div className="portfolio-tags"><span className="tag" style={{color:'var(--green)',borderColor:'rgba(34,197,94,0.3)'}}>SEO</span><span className="tag" style={{color:'var(--secondary)',borderColor:'rgba(245,158,11,0.3)'}}>Content</span></div></div></div>
                    <div className="portfolio-card"><div className="portfolio-img">🏦</div><div className="portfolio-body"><h3 style={{fontSize:'17px',fontWeight:700,marginBottom:'8px'}}>FinTech Web Platform</h3><p style={{fontSize:'13px',color:'var(--muted)'}}>Secure, high-performance platform for a Dubai-based financial services company.</p><div className="portfolio-tags"><span className="tag" style={{color:'var(--primary)',borderColor:'rgba(59,130,246,0.3)'}}>React</span><span className="tag" style={{color:'var(--accent)',borderColor:'rgba(96,165,250,0.3)'}}>AWS</span></div></div></div>
                    <div className="portfolio-card"><div className="portfolio-img">🎓</div><div className="portfolio-body"><h3 style={{fontSize:'17px',fontWeight:700,marginBottom:'8px'}}>EdTech Mobile Platform</h3><p style={{fontSize:'13px',color:'var(--muted)'}}>React Native learning app with AI-generated quizzes for 50,000+ students.</p><div className="portfolio-tags"><span className="tag" style={{color:'var(--secondary)',borderColor:'rgba(245,158,11,0.3)'}}>React Native</span><span className="tag" style={{color:'var(--green)',borderColor:'rgba(34,197,94,0.3)'}}>AI</span></div></div></div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* PAGE: AI PROMPTS */}
            {activePage === 'aiprompts' && (
              <motion.div key="aiprompts" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="page active">
                <div className="container" style={{paddingBottom:'80px'}}>
                  <div className="section-title">
                    <h2 className="serif">Free AI <span style={{color:'var(--primary)'}}>Prompts</span></h2>
                    <p>Copy-ready prompts for SEO, web development, business strategy, and more — crafted by Webnocks experts.</p>
                  </div>
                  <div className="prompt-categories">
                    {["All", "SEO", "Web Dev", "Business", "Data", "Content"].map(cat => (
                      <button 
                        key={cat}
                        className={`cat-btn ${activePromptCat === cat ? 'active' : ''}`}
                        onClick={() => setActivePromptCat(cat)}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                  <div className="prompts-grid">
                    {filteredPrompts.map((p, i) => (
                      <div className="prompt-card" key={i}>
                        <span className="prompt-tag">{p.cat}</span>
                        <h3 className="prompt-title">{p.title}</h3>
                        <p className="prompt-desc">{p.desc}</p>
                        <div className="prompt-text">{p.prompt}</div>
                        <button 
                          className={`copy-btn ${copiedIndex === i ? 'copied' : ''}`}
                          onClick={() => copyPrompt(p.prompt, i)}
                        >
                          {copiedIndex === i ? '✓ Copied!' : '📋 Copy Prompt'}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {/* PAGE: PRICING */}
            {activePage === 'pricing' && (
              <motion.div key="pricing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="page active">
                <div className="container" style={{paddingBottom:'80px'}}>
                  <div className="section-title">
                    <h2 className="serif">Simple, <span style={{color:'var(--accent)'}}>Transparent</span> Pricing</h2>
                    <p>Invest in growth. Choose a plan that scales with your ambitions.</p>
                  </div>
                  <div className="pricing-grid">
                    <div className="price-card">
                      <div className="price-name">Starter</div>
                      <div className="price-desc">Perfect for small businesses looking to establish digital presence.</div>
                      <div className="price-amount">₹15,000<span>/mo</span></div>
                      <button className="price-btn secondary" onClick={() => showPage('bookcall')}>Start Growing</button>
                      <div className="price-features">
                        <div className="price-feature"><span className="check">✓</span> Basic SEO Optimization</div>
                        <div className="price-feature"><span className="check">✓</span> 5 Page Website Maintenance</div>
                        <div className="price-feature"><span className="check">✓</span> Monthly Analytics Report</div>
                        <div className="price-feature"><span className="check">✓</span> Email Support (48h SLA)</div>
                        <div className="price-feature"><span className="check">✓</span> Basic Performance Monitoring</div>
                        <div className="price-feature missing"><span className="cross">✕</span> Custom AI Automation</div>
                        <div className="price-feature missing"><span className="cross">✕</span> Power BI Dashboards</div>
                        <div className="price-feature missing"><span className="cross">✕</span> Dedicated Account Manager</div>
                      </div>
                    </div>
                    <div className="price-card popular">
                      <div className="popular-badge">Most Popular</div>
                      <div className="price-name">Growth</div>
                      <div className="price-desc">Comprehensive suite for scaling companies demanding rapid growth.</div>
                      <div className="price-amount">₹35,000<span>/mo</span></div>
                      <button className="price-btn primary" onClick={() => showPage('bookcall')}>Scale Now</button>
                      <div className="price-features">
                        <div className="price-feature"><span className="check">✓</span> Advanced SEO & Content Strategy</div>
                        <div className="price-feature"><span className="check">✓</span> Full Web App Development</div>
                        <div className="price-feature"><span className="check">✓</span> Basic AI Chatbot Integration</div>
                        <div className="price-feature"><span className="check">✓</span> Custom Analytics Dashboard</div>
                        <div className="price-feature"><span className="check">✓</span> Priority Support (24h SLA)</div>
                        <div className="price-feature"><span className="check">✓</span> Quarterly Strategy Reviews</div>
                        <div className="price-feature missing"><span className="cross">✕</span> Custom Large Language Models</div>
                      </div>
                    </div>
                    <div className="price-card">
                      <div className="price-name">Pro</div>
                      <div className="price-desc">Full-scale digital transformation for ambitious, fast-growing businesses.</div>
                      <div className="price-amount">Custom</div>
                      <button className="price-btn secondary" onClick={() => showPage('bookcall')}>Contact Sales</button>
                      <div className="price-features">
                        <div className="price-feature"><span className="check">✓</span> Dedicated Engineering Squad</div>
                        <div className="price-feature"><span className="check">✓</span> Custom AI & Agent Workflows</div>
                        <div className="price-feature"><span className="check">✓</span> Advanced Cloud Architecture</div>
                        <div className="price-feature"><span className="check">✓</span> Enterprise Data Intelligence</div>
                        <div className="price-feature"><span className="check">✓</span> 24/7 Priority Support (1h SLA)</div>
                        <div className="price-feature"><span className="check">✓</span> Custom Security Audits</div>
                        <div className="price-feature"><span className="check">✓</span> Dedicated Account Manager</div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* PAGE: VISION */}
            {activePage === 'vision' && (
              <motion.div key="vision" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="page active">
                <div className="container" style={{paddingBottom:'80px'}}>
                  <div className="section-title">
                    <span className="badge" style={{marginBottom:'16px'}}>Master Plan</span>
                    <h2 className="serif" style={{fontSize:'clamp(36px,6vw,72px)'}}>Build. <span className="grad-text">Scale.</span> Grow.</h2>
                    <p>Our goal is not just to build a company — we are building a global digital ecosystem where AI, tools, and services all come together to grow businesses worldwide.</p>
                    <div style={{marginTop:'20px',display:'inline-flex',alignItems:'center',gap:'8px',padding:'10px 20px',background:'var(--card)',border:'1px solid var(--border)',borderRadius:'50px',color:'var(--muted)',fontSize:'13px'}}>🚀 Journey: Freelancer → Agency → SaaS Company → Global MNC</div>
                  </div>

                  <h3 className="serif" style={{fontSize:'28px',textAlign:'center',marginBottom:'32px'}}>Our <span style={{color:'var(--primary)'}}>Growth Roadmap</span></h3>
                  <div className="roadmap-grid" style={{marginBottom:'80px'}}>
                    <div className="roadmap-card active"><div className="active-dot"></div><div className="roadmap-num">01</div><h3 style={{fontSize:'19px',fontWeight:700,marginBottom:'8px'}}>Freelancer</h3><p style={{fontSize:'14px',color:'var(--muted)'}}>Start with website projects, logo design & basic SEO for local businesses.</p><span className="active-badge">Active Phase</span></div>
                    <div className="roadmap-card active"><div className="active-dot"></div><div className="roadmap-num">02</div><h3 style={{fontSize:'19px',fontWeight:700,marginBottom:'8px'}}>Agency</h3><p style={{fontSize:'14px',color:'var(--muted)'}}>Scale to a full-service digital agency with a team of specialists.</p><span className="active-badge">Active Phase</span></div>
                    <div className="roadmap-card" style={{opacity:'.6'}}><div className="roadmap-num">03</div><h3 style={{fontSize:'19px',fontWeight:700,marginBottom:'8px'}}>SaaS Company</h3><p style={{fontSize:'14px',color:'var(--muted)'}}>Launch AI-powered tools — website builder, automation platform, CRM.</p></div>
                    <div className="roadmap-card" style={{opacity:'.6'}}><div className="roadmap-num">04</div><h3 style={{fontSize:'19px',fontWeight:700,marginBottom:'8px'}}>Global MNC</h3><p style={{fontSize:'14px',color:'var(--muted)'}}>Operate across 50+ countries with enterprise contracts and global brand.</p></div>
                  </div>

                  <div style={{textAlign:'center',marginBottom:'32px'}}><span className="tag-label">Phase 1</span><h3 className="serif" style={{fontSize:'26px'}}>Core Services <span style={{color:'var(--muted)',fontSize:'18px'}}>(Start Phase)</span></h3></div>
                  <div className="grid-4" style={{marginBottom:'80px'}}>
                    <div className="card"><div className="card-icon" style={{background:'rgba(59,130,246,0.12)'}}>🌐</div><h3>Website Development</h3><p>Business, Portfolio & E-commerce websites</p></div>
                    <div className="card"><div className="card-icon" style={{background:'rgba(245,158,11,0.12)'}}>⭐</div><h3>Logo & Branding</h3><p>Modern logos and complete brand identity</p></div>
                    <div className="card"><div className="card-icon" style={{background:'rgba(34,197,94,0.12)'}}>📈</div><h3>Basic SEO Setup</h3><p>On-page SEO to rank on Google</p></div>
                    <div className="card"><div className="card-icon" style={{background:'rgba(249,115,22,0.12)'}}>🎯</div><h3>Landing Pages</h3><p>High-converting pages for ads & campaigns</p></div>
                  </div>

                  <div style={{textAlign:'center',marginBottom:'32px'}}><span className="tag-label" style={{color:'var(--secondary)'}}>Phase 2</span><h3 className="serif" style={{fontSize:'26px'}}>Growth Services <span style={{color:'var(--muted)',fontSize:'18px'}}>(Scale Phase)</span></h3></div>
                  <div className="grid-4" style={{marginBottom:'80px'}}>
                    <div className="card" style={{borderColor:'rgba(245,158,11,0.2)'}}><div className="card-icon" style={{background:'rgba(59,130,246,0.12)'}}>🧠</div><h3>AI Website Generator</h3><p>Type a prompt — get a complete website</p></div>
                    <div className="card" style={{borderColor:'rgba(245,158,11,0.2)'}}><div className="card-icon" style={{background:'rgba(234,179,8,0.12)'}}>⚡</div><h3>Chatbot Integration</h3><p>AI agents for customer support & sales</p></div>
                    <div className="card" style={{borderColor:'rgba(245,158,11,0.2)'}}><div className="card-icon" style={{background:'rgba(96,165,250,0.12)'}}>🔧</div><h3>Automation Systems</h3><p>Email, WhatsApp & workflow automation</p></div>
                    <div className="card" style={{borderColor:'rgba(245,158,11,0.2)'}}><div className="card-icon" style={{background:'rgba(239,68,68,0.12)'}}>📊</div><h3>CRM & Dashboards</h3><p>Custom CRM and analytics systems</p></div>
                  </div>

                  <div style={{textAlign:'center',marginBottom:'32px'}}><span className="tag-label" style={{color:'var(--accent)'}}>Phase 3 — MNC Level</span><h3 className="serif" style={{fontSize:'26px'}}>Product Strategy</h3><p style={{color:'var(--muted)'}}>Service → Product = Passive income + global scale</p></div>
                  <div className="grid-2" style={{maxWidth:'720px',margin:'0 auto 80px'}}>
                    <div className="card" style={{display:'flex',gap:'16px',alignItems:'flex-start'}}><div className="card-icon" style={{background:'rgba(96,165,250,0.1)',flexShrink:0}}>🔧</div><div><div style={{display:'flex',alignItems:'center',gap:'10px',marginBottom:'6px'}}><h3 style={{fontSize:'15px',margin:0}}>Website Builder Tool</h3><span style={{fontSize:'10px',padding:'2px 10px',borderRadius:'50px',background:'rgba(96,165,250,0.1)',color:'var(--accent)',border:'1px solid rgba(96,165,250,0.2)'}}>Coming Soon</span></div><p style={{fontSize:'13px'}}>No-code drag & drop website builder</p></div></div>
                    <div className="card" style={{display:'flex',gap:'16px',alignItems:'flex-start'}}><div className="card-icon" style={{background:'rgba(59,130,246,0.1)',flexShrink:0}}>🧠</div><div><div style={{display:'flex',alignItems:'center',gap:'10px',marginBottom:'6px'}}><h3 style={{fontSize:'15px',margin:0}}>AI Website Generator</h3><span style={{fontSize:'10px',padding:'2px 10px',borderRadius:'50px',background:'rgba(59,130,246,0.1)',color:'var(--primary)',border:'1px solid rgba(59,130,246,0.2)'}}>In Development</span></div><p style={{fontSize:'13px'}}>Prompt → Full website in minutes</p></div></div>
                    <div className="card" style={{display:'flex',gap:'16px',alignItems:'flex-start'}}><div className="card-icon" style={{background:'rgba(34,197,94,0.1)',flexShrink:0}}>🛒</div><div><div style={{display:'flex',alignItems:'center',gap:'10px',marginBottom:'6px'}}><h3 style={{fontSize:'15px',margin:0}}>E-commerce Builder</h3><span style={{fontSize:'10px',padding:'2px 10px',borderRadius:'50px',background:'rgba(34,197,94,0.1)',color:'var(--green)',border:'1px solid rgba(34,197,94,0.2)'}}>Planned</span></div><p style={{fontSize:'13px'}}>Launch online stores instantly</p></div></div>
                    <div className="card" style={{display:'flex',gap:'16px',alignItems:'flex-start'}}><div className="card-icon" style={{background:'rgba(234,179,8,0.1)',flexShrink:0}}>⚡</div><div><div style={{display:'flex',alignItems:'center',gap:'10px',marginBottom:'6px'}}><h3 style={{fontSize:'15px',margin:0}}>Marketing Automation</h3><span style={{fontSize:'10px',padding:'2px 10px',borderRadius:'50px',background:'rgba(234,179,8,0.1)',color:'#eab308',border:'1px solid rgba(234,179,8,0.2)'}}>Planned</span></div><p style={{fontSize:'13px'}}>All-in-one marketing automation tool</p></div></div>
                  </div>

                  <h3 className="serif" style={{fontSize:'28px',textAlign:'center',marginBottom:'32px'}}>Revenue <span style={{color:'var(--primary)'}}>Streams</span></h3>
                  <div className="revenue-grid" style={{marginBottom:'80px'}}>
                    <div className="revenue-card"><div style={{fontSize:'28px',marginBottom:'12px'}}>💰</div><h3 style={{fontSize:'17px',fontWeight:700,marginBottom:'8px'}}>One-time Projects</h3><p style={{fontSize:'13px',color:'var(--muted)'}}>Website, logo & setup fees</p></div>
                    <div className="revenue-card"><div style={{fontSize:'28px',marginBottom:'12px'}}>📅</div><h3 style={{fontSize:'17px',fontWeight:700,marginBottom:'8px'}}>Monthly Maintenance</h3><p style={{fontSize:'13px',color:'var(--muted)'}}>Ongoing SEO & support retainers</p></div>
                    <div className="revenue-card"><div style={{fontSize:'28px',marginBottom:'12px'}}>⚡</div><h3 style={{fontSize:'17px',fontWeight:700,marginBottom:'8px'}}>SaaS Subscriptions</h3><p style={{fontSize:'13px',color:'var(--muted)'}}>Recurring tool & platform revenue</p></div>
                    <div className="revenue-card"><div style={{fontSize:'28px',marginBottom:'12px'}}>⭐</div><h3 style={{fontSize:'17px',fontWeight:700,marginBottom:'8px'}}>Templates & Courses</h3><p style={{fontSize:'13px',color:'var(--muted)'}}>Digital products & training programs</p></div>
                  </div>

                  <h3 className="serif" style={{fontSize:'28px',textAlign:'center',marginBottom:'32px'}}>Advanced Website <span style={{color:'var(--accent)'}}>Feature Stack</span></h3>
                  <div className="features-grid" style={{marginBottom:'80px'}}>
                    <div className="feature-cat" style={{borderColor:'rgba(59,130,246,0.4)'}}><h3>Frontend</h3><ul className="feature-list"><li>Fast loading optimization</li><li>Responsive mobile + desktop</li><li>Dark mode + animations</li><li>Smooth scroll effects</li></ul></div>
                    <div className="feature-cat" style={{borderColor:'rgba(96,165,250,0.4)'}}><h3>AI Features</h3><ul className="feature-list"><li>AI chatbot support</li><li>AI content generator</li><li>AI website builder</li><li>Smart analytics</li></ul></div>
                    <div className="feature-cat" style={{borderColor:'rgba(34,197,94,0.4)'}}><h3>Business Tools</h3><ul className="feature-list"><li>CRM system</li><li>Payment gateway</li><li>Email automation</li><li>Admin dashboard</li></ul></div>
                    <div className="feature-cat" style={{borderColor:'rgba(239,68,68,0.4)'}}><h3>Security</h3><ul className="feature-list"><li>SSL encryption</li><li>Secure login</li><li>Firewall protection</li><li>Data backup</li></ul></div>
                    <div className="feature-cat" style={{borderColor:'rgba(234,179,8,0.4)'}}><h3>SEO & Marketing</h3><ul className="feature-list"><li>SEO optimization</li><li>Google Analytics</li><li>Keyword tracking</li><li>Social media integration</li></ul></div>
                    <div className="feature-cat" style={{borderColor:'rgba(59,130,246,0.4)'}}><h3>Global Features</h3><ul className="feature-list"><li>Multi-language support</li><li>Multi-currency</li><li>Cloud hosting</li><li>CDN optimization</li></ul></div>
                  </div>

                  <div style={{textAlign:'center',padding:'64px 40px',background:'linear-gradient(135deg,rgba(59,130,246,0.08),rgba(8,8,16,0) 60%,rgba(245,158,11,0.06))',border:'1px solid rgba(59,130,246,0.2)',borderRadius:'32px'}}>
                    <h2 className="serif" style={{fontSize:'clamp(26px,4vw,44px)',marginBottom:'16px'}}>Ready to be part of the <span className="grad-text">Web Nocks ecosystem?</span></h2>
                    <p style={{color:'var(--muted)',maxWidth:'560px',margin:'0 auto 36px',fontSize:'17px'}}>Start small, grow big. Let us engineer your digital future — one project at a time.</p>
                    <a className="btn-primary-lg" onClick={() => showPage('bookcall')} style={{margin:'0 auto'}}>Start Your Journey →</a>
                  </div>
                </div>
              </motion.div>
            )}

            {/* PAGE: ABOUT */}
            {activePage === 'about' && (
              <motion.div key="about" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="page active">
                <div className="container" style={{paddingBottom:'80px'}}>
                  <div className="founder-section">
                    <div className="founder-avatar"><div className="founder-avatar-inner"><span className="founder-initials">AK</span></div></div>
                    <div>
                      <h1 className="serif" style={{fontSize:'clamp(28px,4vw,52px)',marginBottom:'8px'}}>Abhijeet Singh Kushwaha</h1>
                      <h3 style={{color:'var(--primary)',fontSize:'18px',fontWeight:600,marginBottom:'20px'}}>Founder & CTO</h3>
                      <p style={{fontSize:'17px',color:'var(--muted)',lineHeight:1.75}}>Abhijeet founded Webnocks with a singular vision: to give every business — from a local clinic to a global enterprise — access to world-class digital growth tools. As an engineer and strategist at heart, he believes the right blend of AI, SEO, and powerful web technology can solve the most complex business growth challenges. Under his leadership, Webnocks serves clients in 20+ countries worldwide.</p>
                    </div>
                  </div>
                  <div className="grid-2">
                    <div>
                      <h2 className="serif" style={{fontSize:'28px',marginBottom:'28px'}}>Leadership Team</h2>
                      <div className="team-grid">
                        <div className="team-card"><div className="team-avatar" style={{background:'var(--primary)'}}>AK</div><div><div style={{fontWeight:700,fontSize:'15px'}}>Abhijeet Singh Kushwaha</div><div style={{fontSize:'13px',color:'var(--muted)'}}>Founder & CTO</div></div></div>
                        <div className="team-card"><div className="team-avatar" style={{background:'var(--secondary)'}}>AH</div><div><div style={{fontWeight:700,fontSize:'15px'}}>Ahmad</div><div style={{fontSize:'13px',color:'var(--muted)'}}>CEO</div></div></div>
                        <div className="team-card"><div className="team-avatar" style={{background:'var(--accent)'}}>KA</div><div><div style={{fontWeight:700,fontSize:'15px'}}>Kajal</div><div style={{fontSize:'13px',color:'var(--muted)'}}>Data Head</div></div></div>
                        <div className="team-card"><div className="team-avatar" style={{background:'#22c55e'}}>DI</div><div><div style={{fontWeight:700,fontSize:'15px'}}>Dipanshu</div><div style={{fontSize:'13px',color:'var(--muted)'}}>SEO Lead</div></div></div>
                      </div>
                    </div>
                    <div>
                      <h2 className="serif" style={{fontSize:'28px',marginBottom:'28px'}}>Technical Expertise</h2>
                      <div id="skillBars">
                        <div className="skill-bar-row"><div className="skill-label"><span>AI / Python</span><span>95%</span></div><div className="skill-track"><motion.div initial={{ width: 0 }} animate={{ width: '95%' }} transition={{ duration: 1.2, ease: "easeOut" }} className="skill-fill" style={{background:'var(--primary)'}}></motion.div></div></div>
                        <div className="skill-bar-row"><div className="skill-label"><span>SEO & Growth</span><span>92%</span></div><div className="skill-track"><motion.div initial={{ width: 0 }} animate={{ width: '92%' }} transition={{ duration: 1.2, ease: "easeOut" }} className="skill-fill" style={{background:'#22c55e'}}></motion.div></div></div>
                        <div className="skill-bar-row"><div className="skill-label"><span>Data Analytics</span><span>90%</span></div><div className="skill-track"><motion.div initial={{ width: 0 }} animate={{ width: '90%' }} transition={{ duration: 1.2, ease: "easeOut" }} className="skill-fill" style={{background:'var(--accent)'}}></motion.div></div></div>
                        <div className="skill-bar-row"><div className="skill-label"><span>Web Development</span><span>88%</span></div><div className="skill-track"><motion.div initial={{ width: 0 }} animate={{ width: '88%' }} transition={{ duration: 1.2, ease: "easeOut" }} className="skill-fill" style={{background:'var(--secondary)'}}></motion.div></div></div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* PAGE: CAREERS */}
            {activePage === 'careers' && (
              <motion.div key="careers" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="page active">
                <div className="container" style={{paddingBottom:'80px',maxWidth:'880px'}}>
                  <div className="section-title">
                    <h2 className="serif">Join <span style={{color:'var(--primary)'}}>Webnocks</span></h2>
                    <p>Build the future of digital business. We're always looking for exceptional talent to join our global, remote-friendly team.</p>
                  </div>
                  {[
                    {title:'Senior React Engineer', dept:'Web Development', loc:'Remote / Worldwide', type:'Full-time'},
                    {title:'AI/Python Developer', dept:'AI Automation', loc:'Remote', type:'Full-time'},
                    {title:'SEO Specialist', dept:'Growth Marketing', loc:'Remote / Worldwide', type:'Full-time'},
                    {title:'Power BI Analyst', dept:'Data Intelligence', loc:'Remote', type:'Contract'},
                    {title:'B2B Sales Executive', dept:'Lead Generation', loc:'Remote / Worldwide', type:'Full-time'},
                  ].map((role,i)=>(
                    <div key={i} className="role-card">
                      <div>
                        <h3 style={{fontSize:'19px',fontWeight:700}}>{role.title}</h3>
                        <div className="role-meta">
                          <span>💼 {role.dept}</span>
                          <span>📍 {role.loc}</span>
                          <span>🕐 {role.type}</span>
                        </div>
                      </div>
                      <button className="apply-btn" onClick={() => openApply(role.title)}>Apply Now</button>
                    </div>
                  ))}
                  <div className="card" style={{marginTop:'40px',textAlign:'center'}}>
                    <h3 style={{fontSize:'22px',marginBottom:'12px'}}>Don't see your role?</h3>
                    <p style={{color:'var(--muted)',maxWidth:'480px',margin:'0 auto 24px',fontSize:'15px'}}>We are always looking for exceptional talent. Send us your details and tell us why you'd be a great fit.</p>
                    <button className="card-btn" onClick={() => openApply('Open Application')} style={{maxWidth:'280px',margin:'0 auto'}}>Send Open Application</button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* PAGE: BOOK CALL */}
            {activePage === 'bookcall' && (
              <motion.div key="bookcall" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="page active">
                <div className="container" style={{paddingBottom:'80px',maxWidth:'800px'}}>
                  <div className="section-title">
                    <h2 className="serif">Book a <span style={{color:'var(--primary)'}}>Free Consultation</span></h2>
                    <p>Let's discuss how Webnocks can engineer your digital growth.</p>
                  </div>
                  <div className="card" style={{padding:0,overflow:'hidden'}}>
                    <div className="tab-bar">
                      <div className={`tab ${activeTab === 'calendly' ? 'active' : ''}`} onClick={() => setActiveTab('calendly')}>📅 Schedule Call</div>
                      <div className={`tab ${activeTab === 'form' ? 'active' : ''}`} onClick={() => setActiveTab('form')}>💬 Send Inquiry</div>
                      <div className={`tab ${activeTab === 'whatsapp' ? 'active' : ''}`} onClick={() => setActiveTab('whatsapp')}>📱 WhatsApp</div>
                    </div>
                    {activeTab === 'calendly' && (
                      <div className="tab-content active" id="tab-calendly">
                        <iframe src="https://calendly.com/abhijeetkushwaha90/30min?embed_type=Inline" width="100%" height="650" frameBorder="0" title="Schedule a Call"></iframe>
                      </div>
                    )}
                    {activeTab === 'form' && (
                      <div className="tab-content active" id="tab-form" style={{padding:'40px'}}>
                        <form onSubmit={handleContactSubmit}>
                          <div className="form-grid2">
                            <div className="form-group"><label>Name</label><input required type="text" className="form-input" placeholder="John Doe" /></div>
                            <div className="form-group"><label>Email</label><input required type="email" className="form-input" placeholder="john@company.com" /></div>
                          </div>
                          <div className="form-group"><label>Service Required</label><select className="form-input"><option>AI Automation</option><option>SEO & Growth</option><option>Web Development</option><option>Data / Power BI</option><option>Other</option></select></div>
                          <div className="form-group"><label>Project Details</label><textarea required className="form-input" rows={5} placeholder="Tell us about your goals..."></textarea></div>
                          <button type="submit" className="btn-submit">Submit Inquiry</button>
                        </form>
                      </div>
                    )}
                    {activeTab === 'whatsapp' && (
                      <div className="tab-content active" id="tab-whatsapp" style={{padding:'40px',textAlign:'center',minHeight:'300px',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center'}}>
                        <div style={{width:'80px',height:'80px',background:'rgba(34,197,94,0.12)',borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'40px',marginBottom:'20px'}}>📱</div>
                        <h2 style={{fontSize:'26px',fontWeight:700,marginBottom:'12px'}}>Fastest way to reach us</h2>
                        <p style={{color:'var(--muted)',maxWidth:'400px',margin:'0 auto 32px'}}>Skip the forms and emails. Chat directly with our team on WhatsApp for instant replies.</p>
                        <a href="https://wa.me/917068252052" target="_blank" className="btn-primary-lg" style={{background:'#22c55e',boxShadow:'0 0 24px rgba(34,197,94,0.3)'}}>Message +91 7068252052</a>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {/* PAGE: CONTACT */}
            {activePage === 'contact' && (
              <motion.div key="contact" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="page active">
                <div className="container" style={{paddingBottom:'80px'}}>
                  <div className="contact-grid">
                    <div>
                      <h1 className="serif" style={{fontSize:'clamp(32px,4vw,52px)',marginBottom:'16px'}}>Get in <span style={{color:'var(--primary)'}}>Touch</span></h1>
                      <p style={{color:'var(--muted)',fontSize:'17px',marginBottom:'48px',lineHeight:1.7}}>Ready to elevate your business? Reach out to us. We serve clients globally from our HQ in India.</p>
                      <div className="contact-item"><div className="contact-icon" style={{background:'rgba(59,130,246,0.1)'}}>📍</div><div><h3 style={{fontWeight:700,marginBottom:'4px'}}>Headquarters</h3><p style={{color:'var(--muted)',fontSize:'15px'}}>Global Headquarters<br/>Remote & Worldwide Operations</p></div></div>
                      <div className="contact-item"><div className="contact-icon" style={{background:'rgba(34,197,94,0.1)'}}>📱</div><div><h3 style={{fontWeight:700,marginBottom:'4px'}}>Phone / WhatsApp</h3><p style={{color:'var(--muted)',fontSize:'15px'}}>+91 7068252052</p></div></div>
                      <div className="contact-item"><div className="contact-icon" style={{background:'rgba(245,158,11,0.1)'}}>✉️</div><div><h3 style={{fontWeight:700,marginBottom:'4px'}}>Email</h3><p style={{color:'var(--muted)',fontSize:'15px'}}>admin@webnocks.work</p></div></div>
                      <div className="contact-item"><div className="contact-icon" style={{background:'rgba(96,165,250,0.1)'}}>📷</div><div><h3 style={{fontWeight:700,marginBottom:'4px'}}>Instagram</h3><p style={{color:'var(--muted)',fontSize:'15px'}}>@webnocks.work</p></div></div>
                    </div>
                    <div className="card" style={{border:'1px solid rgba(59,130,246,0.25)'}}>
                      <div style={{display:'flex',alignItems:'center',gap:'10px',marginBottom:'24px'}}>
                        <div style={{width:'40px',height:'40px',background:'rgba(34,197,94,0.12)',borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'20px'}}>💬</div>
                        <div>
                          <h3 style={{fontSize:'20px',fontWeight:700}}>Send a Message</h3>
                          <p style={{fontSize:'12px',color:'var(--muted)'}}>Replies via WhatsApp within minutes</p>
                        </div>
                      </div>
                      <form onSubmit={handleContactSubmit}>
                        <div className="form-grid2">
                          <div className="form-group">
                            <label>Your Name</label>
                            <input required type="text" className="form-input" placeholder="John Doe" value={contactName} onChange={e=>setContactName(e.target.value)} />
                          </div>
                          <div className="form-group">
                            <label>Email Address</label>
                            <input required type="email" className="form-input" placeholder="john@company.com" value={contactEmail} onChange={e=>setContactEmail(e.target.value)} />
                          </div>
                        </div>
                        <div className="form-group">
                          <label>Service You Need</label>
                          <select className="form-input" value={contactService} onChange={e=>setContactService(e.target.value)}>
                            <option>SEO & Growth Marketing</option>
                            <option>Website Development</option>
                            <option>AI Automation & Chatbots</option>
                            <option>Lead Generation</option>
                            <option>Logo & Brand Design</option>
                            <option>Data / Power BI Dashboard</option>
                            <option>Cloud & DevOps</option>
                            <option>Other / Not Sure</option>
                          </select>
                        </div>
                        <div className="form-group">
                          <label>Monthly Budget</label>
                          <select className="form-input" value={contactBudget} onChange={e=>setContactBudget(e.target.value)}>
                            <option>Under ₹15,000/mo</option>
                            <option>₹15,000 – ₹35,000/mo</option>
                            <option>₹35,000 – ₹1,00,000/mo</option>
                            <option>₹1,00,000+/mo</option>
                            <option>One-time project</option>
                          </select>
                        </div>
                        <div className="form-group">
                          <label>Tell Us About Your Business & Goals</label>
                          <textarea required className="form-input" rows={4} placeholder="What does your business do? What results are you looking for?" value={contactMsg} onChange={e=>setContactMsg(e.target.value)}></textarea>
                        </div>
                        <button type="submit" className="btn-submit" style={{display:'flex',alignItems:'center',justifyContent:'center',gap:'8px'}}>
                          <span>💬</span> Send via WhatsApp
                        </button>
                        <p style={{textAlign:'center',fontSize:'12px',color:'var(--muted)',marginTop:'10px'}}>Your details will open in WhatsApp — just hit send.</p>
                      </form>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* FOOTER */}
        <footer>
          <div className="container">
            <div className="footer-grid">
              <div className="footer-brand">
                <a className="nav-logo" onClick={() => showPage('home')}>Webnocks</a>
                <p>A Global IT Conglomerate empowering businesses with world-class AI Automation, SEO, Web Development, and Data Intelligence solutions.</p>
                <div className="social-links">
                  <a href="https://instagram.com/webnocks.work" target="_blank" className="social-link" title="Instagram">📷</a>
                  <a href="https://wa.me/917068252052" target="_blank" className="social-link" title="WhatsApp">💬</a>
                  <a href="mailto:admin@webnocks.work" className="social-link" title="Email">✉️</a>
                </div>
              </div>
              <div className="footer-col">
                <h3>Company</h3>
                <ul>
                  <li><a onClick={() => showPage('about')}>About Us</a></li>
                  <li><a onClick={() => showPage('services')}>Services</a></li>
                  <li><a onClick={() => showPage('portfolio')}>Portfolio</a></li>
                  <li><a onClick={() => showPage('vision')}>Our Vision</a></li>
                  <li><a onClick={() => showPage('careers')}>Careers</a></li>
                  <li><a onClick={() => showPage('pricing')}>Pricing</a></li>
                </ul>
              </div>
              <div className="footer-col">
                <h3>Contact</h3>
                <div className="contact-detail">📍 Global, Remote-First</div>
                <div className="contact-detail">📱 +91 7068252052</div>
                <div className="contact-detail">✉️ admin@webnocks.work</div>
                <div style={{marginTop:'16px'}}><a className="btn-cta" onClick={() => showPage('bookcall')}>Free Consultation</a></div>
              </div>
            </div>
            <div className="footer-bottom">
              <p>© {new Date().getFullYear()} Webnocks. All rights reserved. | </p>
              <div style={{display:'flex',gap:'20px'}}><a href="#">Privacy Policy</a><a href="#">Terms of Service</a></div>
            </div>
          </div>
        </footer>

        {/* APPLICATION MODAL */}
        <AnimatePresence>
          {applyModal.open && (
            <motion.div
              initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}
              style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.75)',backdropFilter:'blur(6px)',zIndex:500,display:'flex',alignItems:'center',justifyContent:'center',padding:'20px'}}
              onClick={e=>{ if(e.target===e.currentTarget) setApplyModal({open:false,role:""}) }}
            >
              <motion.div
                initial={{opacity:0,scale:.94,y:30}} animate={{opacity:1,scale:1,y:0}} exit={{opacity:0,scale:.94,y:30}}
                transition={{type:'spring',stiffness:300,damping:28}}
                style={{background:'#0c0c15',border:'1px solid rgba(59,130,246,0.3)',borderRadius:'24px',width:'100%',maxWidth:'620px',maxHeight:'90vh',overflowY:'auto',boxShadow:'0 0 60px rgba(59,130,246,0.12)'}}
              >
                {/* Modal Header */}
                <div style={{padding:'28px 32px 0',borderBottom:'1px solid rgba(59,130,246,0.12)',paddingBottom:'20px',position:'sticky',top:0,background:'#0c0c15',zIndex:1,borderRadius:'24px 24px 0 0'}}>
                  <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
                    <div>
                      <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.1em',color:'var(--secondary)',marginBottom:'6px'}}>Job Application</div>
                      <h2 style={{fontFamily:'Playfair Display,serif',fontSize:'24px',fontWeight:800,marginBottom:'4px'}}>{applyModal.role}</h2>
                      <p style={{fontSize:'13px',color:'var(--muted)'}}>Fill in your details — we'll review and get back to you on WhatsApp.</p>
                    </div>
                    <button onClick={()=>setApplyModal({open:false,role:""})} style={{background:'rgba(255,255,255,0.06)',border:'none',color:'var(--muted)',cursor:'pointer',fontSize:'20px',width:'36px',height:'36px',borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,marginLeft:'16px'}}>✕</button>
                  </div>
                </div>

                {/* Modal Form */}
                <form onSubmit={handleApplicationSubmit} style={{padding:'28px 32px 32px'}}>
                  <div className="form-grid2">
                    <div className="form-group">
                      <label>Full Name *</label>
                      <input required type="text" className="form-input" placeholder="Priya Sharma" value={appName} onChange={e=>setAppName(e.target.value)} />
                    </div>
                    <div className="form-group">
                      <label>Email Address *</label>
                      <input required type="email" className="form-input" placeholder="priya@email.com" value={appEmail} onChange={e=>setAppEmail(e.target.value)} />
                    </div>
                  </div>
                  <div className="form-grid2">
                    <div className="form-group">
                      <label>Phone / WhatsApp *</label>
                      <input required type="tel" className="form-input" placeholder="+91 9876543210" value={appPhone} onChange={e=>setAppPhone(e.target.value)} />
                    </div>
                    <div className="form-group">
                      <label>Years of Experience</label>
                      <select className="form-input" value={appExp} onChange={e=>setAppExp(e.target.value)}>
                        <option>0–1 years (Fresher)</option>
                        <option>1–2 years</option>
                        <option>2–4 years</option>
                        <option>4–7 years</option>
                        <option>7+ years</option>
                      </select>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>LinkedIn Profile URL</label>
                    <input type="url" className="form-input" placeholder="https://linkedin.com/in/yourname" value={appLinkedIn} onChange={e=>setAppLinkedIn(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label>Portfolio / GitHub / Website</label>
                    <input type="url" className="form-input" placeholder="https://github.com/yourname" value={appPortfolio} onChange={e=>setAppPortfolio(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label>Why do you want to join Webnocks? *</label>
                    <textarea required className="form-input" rows={4} placeholder="Tell us about your skills, what excites you about this role, and what you can bring to the team..." value={appCover} onChange={e=>setAppCover(e.target.value)}></textarea>
                  </div>

                  {/* Skills self-rating hint */}
                  <div style={{background:'rgba(59,130,246,0.06)',border:'1px solid rgba(59,130,246,0.15)',borderRadius:'12px',padding:'14px 16px',marginBottom:'20px',fontSize:'13px',color:'var(--muted)',lineHeight:1.6}}>
                    💡 <strong style={{color:'var(--text)'}}>Tip:</strong> Be specific in your cover note — mention tools you know, projects you've worked on, and results you've achieved. We review every application personally.
                  </div>

                  <button type="submit" className="btn-submit" style={{display:'flex',alignItems:'center',justifyContent:'center',gap:'8px',fontSize:'16px'}}>
                    <span>💬</span> Submit Application via WhatsApp
                  </button>
                  <p style={{textAlign:'center',fontSize:'12px',color:'var(--muted)',marginTop:'10px'}}>Your details will open in WhatsApp — just hit send. We'll reply within 24 hours.</p>
                </form>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* WHATSAPP FLOAT */}
        <a href="https://wa.me/917068252052" target="_blank" className="wa-float" title="Chat on WhatsApp">💬</a>

        {/* CHATBOT */}
        <button className={`chat-btn ${chatOpen ? 'hidden' : ''}`} onClick={() => setChatOpen(true)} title="Chat with AI">🤖</button>
        
        <AnimatePresence>
          {chatOpen && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }} 
              animate={{ opacity: 1, y: 0 }} 
              exit={{ opacity: 0, y: 20 }} 
              className="chatbox open"
            >
              <div className="chat-header">
                <div className="chat-header-info">
                  <div className="chat-avatar">🤖</div>
                  <div>
                    <div style={{fontWeight:700,fontSize:'13px'}}>Webnocks AI</div>
                    <div style={{fontSize:'11px',color:'var(--muted)'}}><span className="online-dot"></span> Online</div>
                  </div>
                </div>
                <button className="close-chat" onClick={() => setChatOpen(false)}>✕</button>
              </div>
              <div className="chat-messages">
                {messages.map((msg, i) => (
                  <div key={i} className={`msg ${msg.who}`}>{msg.text}</div>
                ))}
                <div ref={messagesEndRef} />
              </div>
              <div className="chat-quick" style={{display:'flex',gap:'6px',padding:'10px',overflowX:'auto'}}>
                <button className="quick-btn" onClick={() => sendChat('What services do you offer?')}>Services?</button>
                <button className="quick-btn" onClick={() => sendChat('How much does SEO cost?')}>SEO pricing?</button>
                <button className="quick-btn" onClick={() => sendChat('How long for results?')}>Timeline?</button>
                <button className="quick-btn" onClick={() => sendChat('Do you work internationally?')}>International?</button>
              </div>
              <div className="chat-input-row">
                <input 
                  className="chat-input" 
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Ask me anything..." 
                  onKeyDown={(e) => e.key === 'Enter' && sendChat()} 
                />
                <button className="chat-send" onClick={() => sendChat()}>➤</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <Toaster />
      </div>
    </QueryClientProvider>
  );
}

export default App;